// types/splidejs-react-splide.d.ts
declare module "@splidejs/react-splide";
