import Image from "next/image";
import Header from "@/components/landing-page/header";
import HowItWorks from "@/components/landing-page/howItWorks";
import Slide from "@/components/landing-page/slider";
import Service from "@/components/landing-page/service";
import Shopping from "@/components/landing-page/shopping";
import GetStarted from "@/components/landing-page/GetSarted";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-between ">
      <Header />
      <Slide />
      <HowItWorks />
      <Service />
      <Shopping />
      <GetStarted />
    </div>
  );
}
