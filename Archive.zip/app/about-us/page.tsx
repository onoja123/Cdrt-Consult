import Title from "@/components/about-us/title";
import Gallery from "@/components/about-us/gallery";
import RC_About from "@/components/about-us/rc_about";
import RC_About2 from "@/components/about-us/rc_about2";
import Patners from "@/components/about-us/patners";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-between w-full mx-auto overflow-hidden ">
      <Title />
      <Gallery />
      <RC_About />
      <RC_About2 />
      <Patners />
    </div>
  );
}
