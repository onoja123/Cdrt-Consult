import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import dynamic from "next/dynamic";

// Dynamically import Navbar with no SSR
const Navbar = dynamic(() => import("@/components/Navbar"), {
  suspense: true,
  ssr: false,
});
const Footer = dynamic(() => import("@/components/footer"), {
  suspense: true,
  ssr: false,
});

export const metadata: Metadata = {
  title: "Bazaar",
  description: "Artisan's app",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html>
      <body>
        <Navbar />
        {children}
        <Footer />
      </body>
    </html>
  );
}
