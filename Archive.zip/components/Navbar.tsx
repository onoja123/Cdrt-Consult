"use client";
import React, { useState } from "react";
import Image from "next/image";
import RC_logo from "@/public/icons/rc_logo.svg";
import close_navbar from "@/public/icons/close2.svg";
import open_navbar from "@/public/icons/hamburger.svg";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import LabelButtons from "./button";

const Navbar = () => {
  const router = useRouter();
  const path = usePathname();
  const [mobileView, setMobileView] = useState(false);

  const handleToggleNavbar = () => {
    setMobileView(!mobileView);
  };

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/about-us", label: "About us" },
    { path: "/", label: "Features" },
    { path: "/", label: "Contact us" },
  ];

  const handleSign_In_Up = (page: string) => {
    if (page === "login") {
      router.push("/");
    } else {
      router.push("/");
    }
  };

  return (
    <header className="w-full py-8 sticky ">
      <nav className="flex justify-between gap-36 items-center max-w-[90%] mx-auto lg:max-w-[85%] 2xl:max-w-[85%] relative z-10">
        {/* Logo and Text Container (conditionally rendered) */}

        <Link href={"/"}>
          <div className="flex items-center justify-center gap-4">
            {/* <Image
              src={RC_logo}
              alt="Realcousins Logo"
              width={40.68}
              height={25.69}
            /> */}
            <div className="hidden md:block font-bold text-3xl leading-27 text-colorOrange">
              Bazaar
            </div>
          </div>
        </Link>

        {/* Sidebar (always present, but hidden on larger screens) */}

        {mobileView && (
          <div
            className="bg-[#272727] p-8 fixed left-0 top-0 max-h-fit w-full sm:p-5 sm:w-[35%] md:w-[27%]  border lg:hidden"
            style={{ zIndex: "999" }}
          >
            <div className="flex flex-col gap-12">
              <div className="flex justify-between items-center lg:hidden">
                <Link href={"/"}>
                  <div className="flex justify-start items-center gap-4 ">
                    {/* <Image
                      src={RC_logo}
                      alt="Realcousins Logo"
                      className="text-white"
                      width={40.68}
                      height={25.69}
                    /> */}
                    <div className=" font-bold text-large leading-27 text-colorOrange">
                      Bazaar
                    </div>
                  </div>
                </Link>
                <div
                  className="cursor-pointer"
                  onClick={() => setMobileView(false)}
                >
                  <Image
                    src={close_navbar}
                    alt="close navbar"
                    width={14.3}
                    height={13.3}
                  />
                </div>
              </div>
              <ul className="list-none flex flex-col items-start gap-5">
                {navItems.map((item) => (
                  <li
                    key={item.path}
                    className={
                      path === item.path ? "text-colorOrange" : "text-white"
                    }
                  >
                    <Link
                      href={item.path}
                      className="font-medium text-base leading-24 no-underline"
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex gap-10 mt-8 sm:gap-5">
              {/* <LabelButtons
                btn_text={"Sign in"}
                variant={"outlined"}
                textTransform={"capitalize"}
                fontSize_l={"13px"}
                fontSize_m={"12px"}
                fontWeight={500}
                color={"#084EB7"}
                border={"1px solid #084EB7"}
                onClick={() => handleSign_In_Up("login")}
              /> */}
              <LabelButtons
                btn_text={"Join waitlist"}
                variant={"contained"}
                textTransform={"capitalize"}
                fontSize_l={"13px"}
                fontSize_m={"12px"}
                fontWeight={500}
                color={"#FFFFFF"}
                backgroundColor={"#272727"}
                border={"1px solid #FF6525"}
                padding={"0.8rem"}
                hoverColor={"#FFFFF"}
                hoverText={"#0000000"}
                onClick={() => router.push("/join-waitlist")}
              />
            </div>
          </div>
        )}

        {/* Full-width Navigation (always present, but hidden on smaller screens) */}
        <div className="hidden w-[60%] justify-between items-center lg:flex">
          <ul className="list-none flex justify-center items-center gap-6">
            {navItems.map((item) => (
              <li
                key={item.path}
                className={path === item.path ? "text-primary" : "text-black"}
              >
                <Link
                  href={item.path}
                  className="font-medium text-base leading-24 no-underline"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex gap-10  sm:gap-5">
            <LabelButtons
              btn_text={"Join Waitlist"}
              variant={"outlined"}
              textTransform={"capitalize"}
              fontSize_l={"17px"}
              fontSize_m={"12px"}
              fontWeight={500}
              color={"#FFFFFF"}
              backgroundColor={"#272727"}
              border={"1px solid #272727"}
              padding={"0.8rem"}
              hoverColor={"#FFFFF"}
              hoverText={"#0000000"}
              onClick={() => router.push("/join-waitlist")}
            />
            {/* <LabelButtons
              btn_text={"Sign up"}
              variant={"contained"}
              textTransform={"capitalize"}
              fontSize_l={"13px"}
              fontSize_m={"12px"}
              fontWeight={500}
              backgroundColor={"#084EB7"}
              onClick={handleSign_In_Up}
            /> */}
          </div>
        </div>

        {/* Sidebar Toggle */}
        <div className="ml-auto cursor-pointer  lg:hidden">
          <div className="open_wrap " onClick={handleToggleNavbar}>
            <Image
              src={open_navbar}
              alt="open navbar"
              width={27.69}
              height={17.14}
            />
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
