import * as React from "react";
import Grid from "@mui/joy/Grid";
import Image from "next/image";
import Icon1 from "@/public/icons/icon1.png";
import Icon2 from "@/public/icons/icon2.png";
import Icon3 from "@/public/icons/iocn3.png";
import Frame1 from "@/public/icons/frame1.png";
import LabelButtons from "../button";
import { useRouter } from "next/navigation";
import svg2 from "@/public/icons/svg2.png";

const data = [
  {
    icon: Icon1,
    title: "Register as an Artisan",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus. Lorem ipsum dolor sit amet,",
  },
  {
    icon: Icon2,
    title: "Register as an Artisan",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus. Lorem ipsum dolor sit amet,",
  },
  {
    icon: Icon3,
    title: "Register as an Artisan",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus. Lorem ipsum dolor sit amet,",
  },
  // Add more items as needed
];

export default function ServiceProvider() {
  const router = useRouter();
  return (
    <div
      style={{
        flexGrow: 1,
        overflow: "hidden",
      }}
    >
      <div className="flex flex-col md:flex-row gap-1 py-3 w-full  relative">
        <div className="flex flex-col ">
          {" "}
          {/* Adjusted class */}
          <div className="w-full p-2">
            <h1 className="text-2xl lg:text-5xl text-[#14183E] font-bold leading-10 py-5">
              Make Money with your
              <p className="lg:pt-2"> Skill in 3 steps</p>
            </h1>
            <div className="flex flex-col gap-5 py-3 ">
              {" "}
              {/* first container */}
              {data.map((item, index) => (
                <div
                  key={index}
                  className="flex flex-col lg:flex-row gap-3 pt-3"
                >
                  <div className="">
                    <Image src={item.icon} alt="Icon" width={40} height={40} />
                  </div>
                  <div className="w-full lg:max-w-[65%]">
                    <h4 className="text-xl font-semibold text-[#5E6282]">
                      {item.title}
                    </h4>
                    <p className="text-sm text-[#5E6282]">{item.content}</p>
                  </div>
                </div>
              ))}
              <div className="w-full lg:w-[30%] pt-3">
                <LabelButtons
                  btn_text={"Join Waitlist"}
                  variant={"outlined"}
                  textTransform={"capitalize"}
                  fontSize_l={"17px"}
                  fontSize_m={"12px"}
                  fontWeight={500}
                  color={"#FFFFFF"}
                  backgroundColor={"#272727"}
                  border={"1px solid #272727"}
                  padding={"0.8rem"}
                  hoverColor={"#FFFFF"}
                  hoverText={"#0000000"}
                  width={"100%"}
                  onClick={() => router.push("/join-waitlist")}
                />
              </div>
            </div>
          </div>
        </div>
        <div className=" flex-1  w-full relative">
          <Image
            src={Frame1}
            className="w-[100%] lg:w-[80%] h-[90%] object-cover rounded-lg"
            alt=""
          />
        </div>
      </div>
    </div>
  );
}
