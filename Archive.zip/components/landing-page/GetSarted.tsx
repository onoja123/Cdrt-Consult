"use client";
import { useRouter } from "next/navigation";
import Newsletter from "./newsletter";

const GetStarted = () => {
  const router = useRouter();
  //   const bookCall = () => {
  //     window.open("https://www.calendly.com", "_blank");
  //   };

  return (
    <div className="bg-[#F9F6FF] w-full overflow-hidden pb-10">
      <div className="w-[85%] lg:w-[60%] text-center justify-center text-white mx-auto py-5">
        <div className="text-3xl py-4">
          <h1 className="pt-8 text-3xl lg:text-6xl text-black font-semibold">
            Find your next ride today with <br />
            Bazaar{" "}
          </h1>
        </div>
        <div className="text-sm py-4 text-gray-500">
          <p>
            Join the community of businesses and traders that are embracing the
            future of finance with Msika.
          </p>
          <p>
            We are committed to empowering 10 million informal workers in Africa
            bosting economy
            <br /> amd empowering lives and citizens in africa
          </p>
        </div>
        <div className="flex flex-wrap justify-center items-center py-7 gap-6">
          <button
            className="cursor-pointer text-white  mx-auto lg:mx-0 text-sm text-center font-semibold text-white-500 px-8 py-3  rounded-full lg:rounded-sm  bg-black hover:opacity-90 motion-reduce:transform-none "
            onClick={() => router.push("/waitlist")}
          >
            Get started
          </button>
          <button
            className="cursor-pointer text-black  mx-auto lg:mx-0 text-sm text-center font-semibold text-white-500 px-8 py-3  rounded-full lg:rounded-sm  border-solid border-2 border-black motion-reduce:transform-none hover:bg-black hover:text-white"
            onClick={() => router.push("/join-waitlist")}
          >
            Conatact us
          </button>
        </div>
      </div>
      <Newsletter />
    </div>
  );
};

export default GetStarted;
