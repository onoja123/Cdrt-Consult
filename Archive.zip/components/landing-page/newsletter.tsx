import React from "react";
import Send from "@/public/icons/send.png";
import Svg from "@/public/icons/svg4.png";
import Image from "next/image";
import { MdEmail } from "react-icons/md";

const newsletter = () => {
  return (
    <div className=" text-center w-full ">
      <div className="w-full lg:w-[80%] mx-auto bg-[#F0F3BD] p-2 lg:p-28  py-28 lg:rounded-tr-[2rem] lg:rounded-tl-[10.9rem] h-fit relative">
        <Image
          src={Send}
          className="absolute right-0 top-0 hidden lg:block"
          alt=""
        />
        <Image src={Svg} className="absolute right-0" alt="" />
        <h1 className="text-lg lg:text-3xl text-[#5E6282] font-semibold ">
          Subscribe to get information, latest news and other <br /> interesting
          offers about Bazaar
        </h1>
        <form className="flex flex-col md:flex-row items-center md:items-start  w-full  mx-auto  lg:py-10 justify-center pt-5  gap-4">
          <div className="relative w-full lg:w-[50%] ">
            <input
              type="email"
              placeholder="Your email address"
              required
              className="w-full p-2 py-3 mb-2 md:mb-0 md:mr-2 border rounded-md outline-none focus:outline-none border-none pl-8 z-50 "
            />
            <MdEmail className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500" />{" "}
          </div>
          <button
            type="submit"
            className="p-2 py-3 px-12 lg:px-4 z-50  bg-[#272727] text-white font-bold rounded-md hover:text-gray-500"
          >
            Subscribe
          </button>
        </form>
      </div>
    </div>
  );
};

export default newsletter;
