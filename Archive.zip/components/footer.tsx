"use client";
import moment from "moment/moment";
import { footerLinks, socialMedia } from "@/ultils/constants";
import { useRouter } from "next/navigation";

const Footer = () => {
  const router = useRouter();

  return (
    <div>
      <section className="py-10  sm:pt-16 lg:pt-24 bg-black">
        <div className="px-4 mx-auto sm:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-2 md:col-span-3 lg:grid-cols-6 gap-y-16 gap-x-12">
            <div className="col-span-2 md:col-span-3 lg:col-span-2 lg:pr-8">
              <div className=" h-auto flex items-start flex-col justify-center">
                <h1 className="text-colorOrange font-bold text-2xl">Bazaar</h1>

                {/* <img
                  className="max-w-full h-32 object-contain"
                  src={logo2}
                  alt="logo"
                /> */}

                <p className="text-base leading-relaxed text-[#E6E6E6]   text-start">
                  We are the catalyst for empowering informal workers and
                  businesses, unlocking their potential through digital
                  transformation and fostering financial inclusion. We are
                  poised to become the all-in-one infrastructure of first choice
                  for offering and accessing legal services and solutions across
                  the World.
                </p>
              </div>
            </div>

            {footerLinks.map((section, index) => (
              <div key={index}>
                <p className="text-sm font-semibold tracking-widest text-[#FFFF] uppercase">
                  {section.title}
                </p>

                <ul className="mt-6 space-y-4">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      {link.url.startsWith("http") ||
                      link.url.startsWith("https") ? (
                        <a
                          href={link.url}
                          title={link.text}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex text-base text-[#E6E6E6] transition-all duration-200 cursor-pointer hover:text-colorOrange focus:text-colorOrange"
                        >
                          {link.text}
                        </a>
                      ) : (
                        <a
                          onClick={() => router.push(link?.url)}
                          title={link.text}
                          className="flex text-base text-[#E6E6E6] transition-all duration-200 cursor-pointer hover:text-colorOrange focus:text-colorOrange"
                        >
                          {link.text}
                        </a>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            <div className="col-span-2 md:col-span-1 lg:col-span-2 lg:pl-8">
              <div className="">
                <p className="text-white">
                  Email: <span className="text-[#E6E6E6]">Bazaar.io</span>
                </p>
                <br />
                <p className="text-white">
                  Nigeria:{" "}
                  <span className="text-[#E6E6E6]">
                    Suite 1, 319, Borno Way off Herbert Macaulay Way,
                    Alagomeji,  Yaba, Lagos.
                  </span>
                </p>
                <br />
                <p className="text-white">
                  USA:{" "}
                  <span className="text-[#E6E6E6]">
                    130, 447 Broadway, 2nd Floor New York, NY 10013
                  </span>
                </p>
              </div>
              <ul className="flex items-center space-x-3 mt-9">
                {socialMedia.map((socialItem) => (
                  <li key={socialItem.id}>
                    <a
                      href={socialItem.link}
                      title=""
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center text-white transition-all duration-200 bg-gray-800 rounded-full w-7 h-7 hover:bg-colorOrange focus:bg-colorOrange"
                    >
                      <socialItem.icon />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pt-8">
            <p className="text-sm text-center text-[#E6E6E6]">
              Copyright © {moment().format("YYYY")}, Bazaar.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Footer;
