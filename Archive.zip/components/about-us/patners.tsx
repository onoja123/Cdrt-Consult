"use client";
import { useRouter } from "next/navigation";
import Newsletter from "../landing-page/newsletter";
import logo1 from "@/public/images/patner1.png";
import logo2 from "@/public/images/patner2.png";
import logo3 from "@/public/images/patner3.png";
import logo4 from "@/public/images/patner4.png";
import Image from "next/image";

const Patners = () => {
  const router = useRouter();
  const partnerLogos = [logo1, logo2, logo1, logo2, logo1];

  return (
    <div className="bg-[#F9F6FF] w-full overflow-hidden py-8">
      <div className="w-[85%] lg:w-[60%] text-center justify-center text-white mx-auto py-5">
        <div className="text-3xl py-4">
          <h1 className="pt-8 text-3xl lg:text-6xl text-black font-semibold">
            Building Strong Alliance, here are our partners
          </h1>
        </div>
        <div className="flex  flex-wrap justify-center items-center py-2 gap-4 lg:gap-20 w-full">
          {partnerLogos.map((logoUrl, index) => (
            <Image
              key={index}
              src={logoUrl}
              alt={`Partner Logo ${index + 1}`}
              className="w-24 h-24 object-cover"
            />
          ))}
        </div>
      </div>
      <Newsletter />
    </div>
  );
};

export default Patners;
