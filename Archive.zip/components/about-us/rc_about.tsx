import React from "react";
import about_img from "@/public/images/bg-about.png";
import star from "@/public/icons/svg2.png";
import bg_vector from "@/public/icons/svg2.png";
import Image from "next/image";

const RC_About = () => {
  return (
    <section className="relative w-full p-2 lg:mt-20">
      <Image
        className="absolute right-0 top-0"
        width={50}
        src={bg_vector}
        alt=""
      />

      <div className="flex flex-col lg:flex-row gap-8  w-full px-2 lg:px-10">
        <div className="w-full lg:w-[40%] order-2 lg:order-1">
          <Image
            className="object-cover w-full h-full"
            src={about_img}
            alt="about image"
          />
        </div>
        <div className="w-full lg:w-[60%] order-1 lg:order-2">
          <div className="rounded-full bg-black text-white w-[6rem] px-2 py-1 text-center">
            About us
          </div>
          <h1 className="text-5xl lg:text-[60px] font-semibold text-[#FF6525] leading-snug">
            Empowering 30m Informal <br />
            workers
          </h1>
          <p className="text-[20px] leading-36 text-[#1A1A1A] my-8">
            We are the catalyst for empowering informal workers and businesses,
            unlocking their potential through digital transformation and
            fostering financial inclusion. We are poised to become the
            all-in-one infrastructure of first choice for offering and accessing
            legal services and solutions across the World.
          </p>
          <p className="text-[20px] leading-36 text-[#1A1A1A] my-8">
            We work with local partners, including vocational schools,
            cooperatives, and police, to onboard and vet workers at scale.
          </p>
        </div>
      </div>

      <Image
        className="absolute right-7 bottom-0"
        width={60}
        src={star}
        alt=""
      />
    </section>
  );
};

export default RC_About;
